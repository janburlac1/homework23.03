import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("vedite cislo :");
        int number = scn.nextInt();
        if (number > 0 && number % 2 !=0){
            System.out.println(number *2);
            if ((number % 10 == 5 || number % 10 == 0) && number >0);
            System.out.println(number +5);

        }
        if (number < 0);{
            System.out.println(Math.abs(number )/3);
            
        }
    }
}