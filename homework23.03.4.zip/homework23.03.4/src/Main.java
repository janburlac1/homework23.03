import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rm = new Random();
        int x1 = rm.nextInt();
        int x2 = rm.nextInt();
        int x3 = rm.nextInt();
        System.out.println("x1 " + x1 + "x2 " + x2 + "x3 " + x3);
        if (x1 >= x2 && x1 >= x3) {
            System.out.println(x1);
            if (x1 >= x2 && x1 >= x3) {
                System.out.println(x2);
                if (x1 >= x2 && x1 >= x3) {
                    System.out.println(x3);
                }
            }
        }
    }
}