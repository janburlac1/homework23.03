import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println(" Vedite dva cisla: ");
        int number = scr.nextInt();
        int number1 = scr.nextInt();
        if (number != number1){
            System.out.println(number + number1);
        }
        else {
            System.out.println(number * number1);
        }

    }
    Random rm = new Random();
    int x1 = rm.nextInt();
    int x2 = rm.nextInt();
    int x3 = rm.nextInt();
    if




    }


